from rest_framework import serializers
from .models import Employees, Department


class EmployeeSerializer(serializers.ModelSerializer):

    class Meta:
        model=Employees
        fields="__all__"

class DepartmentSerializer(serializers.ModelSerializer):

    class Meta:
        model=Department
        fields="__all__"


class SortDepartmentSerializer(serializers.ModelSerializer):

    class Meta:
        model=Employees
        fields=('emp_name',)


class DepdetailsSerializer(serializers.ModelSerializer):

    class Meta:
        model=Employees
        fields="__all__"