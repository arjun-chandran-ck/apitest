from multiprocessing import connection
from sqlite3 import Cursor
from django.shortcuts import render, get_object_or_404,redirect
from django.utils.translation import TranslatorCommentWarning
from rest_framework import serializers
from rest_framework.serializers import Serializer
from .models import *
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User, auth
from django.http import HttpResponseRedirect,HttpResponse,Http404
from django.urls import reverse
from django.contrib import messages
#from .forms import *
from django.urls import reverse_lazy
from django.forms import ModelForm
from django.core.mail import send_mail
from django.contrib.auth.decorators import user_passes_test
from django.conf import settings

from django.views.generic import (DetailView, ListView, FormView, CreateView, UpdateView, DeleteView)
import datetime
from django.core.mail import send_mail




from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from . serializer import DepartmentSerializer, SortDepartmentSerializer, EmployeeSerializer
from django.db import connection

class EmployeeList(APIView):
    def get(self,request):
        query=Employees.objects.all()
        serializer= EmployeeSerializer(query, many=True)
        return Response(serializer.data)
    

class DepartmentList(APIView):
    def get(self,request):
        query=Department.objects.all()
        serializer=DepartmentSerializer(query, many=True)
        return Response(serializer.data)

class EmployeeDetails(APIView):
    def get(self,request,id):
        print(id)
        query=Employees.objects.filter(emp_id=id) 
        serializer=EmployeeSerializer(query,many=True)
        return Response(serializer.data)     


class SortDepDetails(APIView):
    def get(self,request,id):
        print(id)
        q= Department.objects.values('dep_id').filter(dep_name=id)
        print(q)
        for i in q:
            query=Employees.objects.filter(dep_id=i['dep_id'])
        serializer=SortDepartmentSerializer(query,many=True)
        return Response(serializer.data)       

class AddEmp(APIView):
    def post(self,request):
        serializer= EmployeeSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
        return Response(serializer.data)
             

class AddDep(APIView):
    def post(self,request):
        serializer= DepartmentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
        return Response(serializer.data)
             