from django.db import models
from django.conf import settings
from django.contrib.auth.models import User
from django.db.models.deletion import CASCADE
from django.db.models.fields import CharField
from django.db.models.fields.json import DataContains


class Department(models.Model):
    dep_id =models.AutoField(primary_key=True)
    dep_name = models.CharField(max_length=100, default="NIL")

    def __str__(self):
        return str(self.dep_id)


class Employees(models.Model):
    emp_id = models.AutoField(primary_key=True)
    emp_name = models.CharField(max_length=100, default="NIL")
    emp_blood= models.CharField(max_length=100, default="NIL")
    emp_contact= models.CharField(max_length=100, default="NIL")
    emp_address=models.CharField(max_length=100, default="NIL")
    dep_id = models.ForeignKey(Department,on_delete=models.CASCADE)
 

    
    def __str__(self):
        return str(self.emp_id)
