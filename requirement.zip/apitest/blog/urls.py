from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [

    path('employees/',views.EmployeeList.as_view(),name="employees"),
    path('department/',views.DepartmentList.as_view(),name="department"),
    path('employees/<id>/',views.EmployeeDetails.as_view(),name="employees"),
    path('department/<id>/',views.SortDepDetails.as_view(),name="department"),
    path('Addemp/',views.AddEmp.as_view(),name="Addemp"),
    path('Adddep/',views.AddDep.as_view(),name="Adddep"),

           
   

]
